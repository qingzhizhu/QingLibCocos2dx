#!/bin/bash

#用luagit 编译脚本

COMPILER=$COCOS2DX_ROOT/scripting/lua/luajit/LuaJIT-2.0.1/src/luajit

$COMPILER -b extern.lua extern.lua
$COMPILER -b hello.lua hello.lua
$COMPILER -b hello2.lua hello2.lua
$COMPILER -b LuaNode.lua LuaNode.lua



