
require("LuaNode")

function myadd(x, y)
    return x + y
end


function getNode()
	local node = CCNode:create()
	--node:autorelease()
	label = CCLabelTTF:create("lua label","Arial",30)
	node:addChild(label)
	return node
end



function getLuaNode()
	local node = LuaNode:create()
	label = CCLabelTTF:create("lua Node Class","Arial",30)
	node:addChild(label)
	return node
end