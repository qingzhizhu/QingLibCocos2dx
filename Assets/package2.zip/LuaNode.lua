
require("extern")

LuaNode = class("LuaNode",
	function ()
		print("create lua node class!")
		return CCNode:create();
	end
)

LuaNode.__index = LuaNode

function LuaNode:create()
	local node = LuaNode.new()
	--node:autorelease()	--c++ 调用时不要写这句
	return node
end

function LuaNode:enter()
	print("crate lua node onEnter!")
end

